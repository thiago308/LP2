using System.Data.SqlClient;
using System.Data.Sql;





namespace PContato0030482411020
{
    public partial class frmPrincipal : Form

    {
        public static SqlConnection conexao;
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void contextMenuStrip1_Opening(object sender, System.ComponentModel.CancelEventArgs e)
        {

        }

        private void FrmPrincipal_Load(object sender, EventArgs e)
        {
            try
            {
                conexao = new SqlConnection("Aqui vai incluir a string da conexao da escola");
            }
            catch (Exception ex)
            {
                MessageBox.Show("erro ao abrir banco de dados"+ex.Message);
            
            }

        }

    }
}
