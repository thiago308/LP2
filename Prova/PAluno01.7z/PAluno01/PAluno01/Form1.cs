﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAluno01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            int Alunos = 5;
            double sum = 0.0;
            double[,] AlunoXProfessor = new double[Alunos, 3];

            for (int i = 0; i < Alunos; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    string input = Interaction.InputBox($"Aluno {i + 1} Nota Professor {j + 1} ");

                    if (double.TryParse(input, out double nota) && nota >= 0 && nota <= 10)
                    {
                        AlunoXProfessor[i, j] = nota;
                    }
                    else
                    {
                        MessageBox.Show("Nota inválida! Digite um valor entre 0 e 10.");
                        j--;
                    }
                }    
            }
            lstBox.Items.Clear();

            for (int i = 0; i < Alunos; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    sum += AlunoXProfessor[i, j];
                    lstBox.Items.Add($"Aluno {i + 1} Nota Professor {j + 1} {AlunoXProfessor[i, j].ToString("F2")} ");
                }
                lstBox.Items.Add($"Média {(sum / 3).ToString("F2")}");
                sum = 0.0;
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lstBox.Items.Clear();
            double sum = 0.0;
            double[,] AlunoXProfessor = null;
        }
    }
}
