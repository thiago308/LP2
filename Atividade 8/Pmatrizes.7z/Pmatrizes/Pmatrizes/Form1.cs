﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using Microsoft.VisualBasic;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace Pmatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[]vetor = new int[20];
            string auxiliar = "";
            for (var i = 0; i < 20; i++) 
            {
                auxiliar = Interaction.InputBox("Digite o número", "Entrada de dados");
                
                if (!int.TryParse(auxiliar,out vetor[i]))
                {
                    MessageBox.Show("Número Inválido!");
                    i--;

                }
              
               
            
            }
            Array.Reverse(vetor);
            auxiliar = "";
            foreach(int x in vetor)
            {
                auxiliar += x + "\n";

            }

            MessageBox.Show(auxiliar);
        }

        private void btnExercicio2_Click(object sender, EventArgs e)
        {
            {
                ArrayList alunos = new ArrayList() { "Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais" };
                alunos.Remove("Otávio");

                string mensagem = "Lista de alunos:\n";
                foreach (string aluno in alunos)
                {
                    mensagem += aluno + "\n";
                }
                MessageBox.Show(mensagem, "Exercício 2");
            }


        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            int numAlunos = 20;
            int numNotas = 3;
            double[,] notas = new double[numAlunos, numNotas];
            string saida = "";

            for (int i = 0; i < numAlunos; i++)
            {
                for (int j = 0; j < numNotas; j++)
                {
                    string input = Interaction.InputBox($"Digite a nota {j + 1} do aluno {i + 1} (0 a 10)", "Entrada de Dados");

                    if (double.TryParse(input, out double nota) && nota >= 0 && nota <= 10)
                    {
                        notas[i, j] = nota;
                    }
                    else
                    {
                        MessageBox.Show("Nota inválida! Digite um valor entre 0 e 10.");
                        j--;
                    }
                }

                double media = (notas[i, 0] + notas[i, 1] + notas[i, 2]) / numNotas;
                saida += "Aluno " + (i + 1) + ": média: " + media.ToString("F1") + "\n";
            }

            MessageBox.Show(saida, "Médias dos Alunos");
        }

        private void btnExercicio4_Click(object sender, EventArgs e)
        {
            frmEx4 obj = new frmEx4();
            obj.Show();
        }

        private void btnExercicio5_Click(object sender, EventArgs e)
        {
            frmEx5 obj = new frmEx5();
            obj.Show();
        }
    }
}
