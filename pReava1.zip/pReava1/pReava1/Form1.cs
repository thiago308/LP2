﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pReava1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            double[] matriz = new double[10];
            double[] matrizB = new double[10];
            int indice = 0;
            matriz[0] = 1.50;
            matriz[1] = 2.50;
            matriz[2] = 3.50;
            matriz[3] = 4.50;
            matriz[4] = 5.50;
            matriz[5] = 6.50;
            matriz[6] = 7.50;
            matriz[7] = 8.50;
            matriz[8] = 9.50;
            matriz[9] = 10.50;


            
           


            listBox1.Items.Add($"Posição: {indice} - Matriz A: {matriz} - Matriz B: {matrizB}");
            




        }
            //private void btnLimpar_Click(object sender, EventArgs e); }
            
            
               
            //}
        
    

}
}
