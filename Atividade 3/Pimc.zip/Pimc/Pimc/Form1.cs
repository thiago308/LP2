﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;
        public Form1()
        {
            InitializeComponent();
        }

        private void mskbxPeso_Validating(object sender, CancelEventArgs e)
        {
            if ((!Double.TryParse(mskbxPeso.Text, out peso)) ||
                (peso <= 0))
            {
                MessageBox.Show("Peso ínvalido");
                e.Cancel = true;

            }

        }

        private void mskbxAltura_Validating(object sender, CancelEventArgs e)
        {
            if ((!Double.TryParse(mskbxAltura.Text, out altura)) ||
                (altura <= 0))
            {
                MessageBox.Show("Altura Inválida");
                e.Cancel = true;
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            imc = peso / (Math.Pow(altura, 2));
            imc = Math.Round(imc, 1);
            txtImc.Text = imc.ToString();

            if (imc < 18.5)
            {
                MessageBox.Show("Magreza");
            }
            else if (imc < 24.9)
            {
                MessageBox.Show("Normal");
            }
            else if (imc < 29.9)
            {
                MessageBox.Show("Sobrepeso");
            }


            else if (imc < 39.9)
            {
                MessageBox.Show("Obesidade");
            }


            else
                MessageBox.Show("Obesidade grave");
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo?",
                "Saída", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) ==
                DialogResult.Yes)
            {
                Close();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxAltura.Text =string.Empty;
            mskbxPeso.Text = string.Empty;
            txtImc.Text = string.Empty;
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
